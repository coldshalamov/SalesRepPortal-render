namespace LeadManagementPortal.Models
{
    public class SmartyStreetsOptions
    {
        public string? SmartyStreetUrl { get; set; }
        public string? SmartyStreetKey { get; set; }
        public string? Referer { get; set; }
    }
}
