namespace LeadManagementPortal.Models
{
    public static class UserRoles
    {
        public const string OrganizationAdmin = "OrganizationAdmin";
        public const string GroupAdmin = "GroupAdmin";
        public const string SalesRep = "SalesRep";
        public const string SalesOrgAdmin = "SalesOrgAdmin";
    }
}
